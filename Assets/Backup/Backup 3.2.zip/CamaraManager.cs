using UnityEngine;
using System.Collections.Generic;

[System.Serializable]
public class CamaraConfig
{
    public string sceneName;
    public float limiteXMinimo;
    public float limiteXMaximo;
    public float limiteYMinimo;
    public float limiteYMaximo;
}

public class CamaraManager : MonoBehaviour
{
    public static CamaraManager Instance { get; private set; }

    public List<CamaraConfig> camaraConfigs;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public CamaraConfig GetConfigForCurrentScene()
    {
        string currentSceneName = UnityEngine.SceneManagement.SceneManager.GetActiveScene().name;
        foreach (CamaraConfig config in camaraConfigs)
        {
            if (config.sceneName == currentSceneName)
            {
                return config;
            }
        }

        Debug.LogWarning("No camera configuration found for the current scene: " + currentSceneName);
        return null;
    }
}

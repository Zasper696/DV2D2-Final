using UnityEngine;

public class Camara : MonoBehaviour
{
    [SerializeField] public Transform objetivo; // El objeto que seguir� la c�mara (tu jugador)
    [SerializeField] public float limiteXMinimo; // L�mite m�nimo en el eje X
    [SerializeField] public float limiteXMaximo; // L�mite m�ximo en el eje X
    [SerializeField] public float limiteYMinimo; // L�mite m�nimo en el eje Y
    [SerializeField] public float limiteYMaximo; // L�mite m�ximo en el eje Y

    [SerializeField] public float smoothSpeed = 0.125f; // Velocidad de suavizado
    [SerializeField] private Vector3 velocity = Vector3.zero; // Velocidad actual

    void Start()
    {
        // Buscar al jugador autom�ticamente al inicio del juego
        objetivo = GameObject.FindGameObjectWithTag("Player").transform;
    }

    void FixedUpdate() // Usar FixedUpdate para el seguimiento de la c�mara
    {
        if (objetivo != null)
        {
            // Obtener la posici�n actual del objetivo
            Vector3 posicionObjetivo = objetivo.position;

            // Limitar la posici�n en el eje X
            posicionObjetivo.x = Mathf.Clamp(posicionObjetivo.x, limiteXMinimo, limiteXMaximo);

            // Limitar la posici�n en el eje Y
            posicionObjetivo.y = Mathf.Clamp(posicionObjetivo.y, limiteYMinimo, limiteYMaximo);

            // Mantener la misma posici�n en el eje Z
            posicionObjetivo.z = transform.position.z;

            // Asignar la nueva posici�n a la c�mara con suavizado
            transform.position = Vector3.SmoothDamp(transform.position, posicionObjetivo, ref velocity, smoothSpeed);
        }
    }
}

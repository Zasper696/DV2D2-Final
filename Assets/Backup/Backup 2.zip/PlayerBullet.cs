using UnityEngine;

public class PlayerBullet : MonoBehaviour
{
    private Rigidbody2D rb;
    [SerializeField] private float speed = 10f; // Velocidad de la bala
    [SerializeField] private float lifetime = 2f; // Tiempo de vida en segundos
    [SerializeField] private int bulletDamage = 1; // Da�o que inflige la bala

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        // Destruir el proyectil tras el tiempo definido
        Destroy(gameObject, lifetime);
    }

    // M�todo para disparar en una direcci�n espec�fica
    public void SetDirection(Vector2 direction)
    {
        rb.velocity = direction * speed;
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        // Verifica si la bala colisiona con un `EnemySlime`
        if (other.CompareTag("Enemy"))
        {
            EnemySlime enemySlime = other.GetComponent<EnemySlime>();
            if (enemySlime != null)
            {
                // Aplica el da�o al `EnemySlime`
                enemySlime.TakeDamage(bulletDamage);
                // Destruye la bala despu�s de hacer da�o
                Destroy(gameObject);
            }
        }
    }
}

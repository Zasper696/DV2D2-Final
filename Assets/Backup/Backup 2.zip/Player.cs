using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

public class Player : MonoBehaviour
{
    public enum DamageType
    {
        Physical,
        Magical,
        Fire,
        Ice,
        Poison
    }

    [SerializeField] public int maxHealth = 5; // Salud m�xima del jugador
    [SerializeField] private float moveSpeed = 5f; // Velocidad de movimiento del jugador
    [SerializeField] private float deathAnimationTime = 1f; // Duraci�n de la animaci�n de muerte
    [SerializeField] private Color lowHealthColor = Color.red; // Color cuando la salud es baja
    [SerializeField] private int lowHealthThreshold = 2; // Umbral para salud baja
    [SerializeField] private SpriteRenderer spriteRenderer; // Referencia al SpriteRenderer
    [SerializeField] private GameObject bulletPrefab; // Prefab del proyectil
    [SerializeField] private float bulletSpawnRadius = 1f; // Radio al que se genera el proyectil
    [SerializeField] private float fireCooldown = 0.5f; // Tiempo de enfriamiento entre disparos

    [Header("Damage Colors")]
    [SerializeField] private Color physicalDamageColor = Color.gray;
    [SerializeField] private Color magicalDamageColor = Color.blue;
    [SerializeField] private Color fireDamageColor = Color.red;
    [SerializeField] private Color iceDamageColor = Color.cyan;
    [SerializeField] private Color poisonDamageColor = Color.green; // Color para el da�o de veneno
    [SerializeField] private float damageColorDuration = 1f; // Duraci�n del cambio de color

    [Header("Fire Damage Settings")]
    [SerializeField] private float fireDamageCooldownIncrease = 2f; // Incremento del cooldown por da�o de fuego
    [SerializeField] private float fireDamageDuration = 5f; // Duraci�n del incremento del cooldown

    [Header("Ice Damage Settings")]
    [SerializeField] private float iceDamageSpeedReduction = 2f; // Reducci�n de velocidad por da�o de hielo
    [SerializeField] private float iceDamageDuration = 5f; // Duraci�n de la reducci�n de velocidad

    [Header("Poison Damage Settings")]
    [SerializeField] private int poisonDamagePerSecond = 1; // Da�o por segundo del veneno
    [SerializeField] private float poisonDuration = 5f; // Duraci�n del veneno en segundos

    public int currentHealth;
    private Animator animator; // Componente Animator
    private Rigidbody2D rb; // Referencia al Rigidbody2D para manejar el movimiento
    private bool isDead = false;
    private float lastFireTime = 0f; // Tiempo del �ltimo disparo
    private Color originalColor;
    private Coroutine poisonCoroutine;
    private Coroutine fireCooldownCoroutine;
    private Coroutine iceSpeedCoroutine;

    // Variables para almacenar la entrada del jugador
    private float moveHorizontal;
    private float moveVertical;

    void Start()
    {
        currentHealth = maxHealth;
        animator = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        originalColor = spriteRenderer.color; // Guardar el color original
    }

    void Update()
    {
        if (isDead)
            return;

        // Detectar las entradas del jugador (movimiento) solo con WASD
        moveHorizontal = Input.GetKey(KeyCode.A) ? -1 : Input.GetKey(KeyCode.D) ? 1 : 0;
        moveVertical = Input.GetKey(KeyCode.W) ? 1 : Input.GetKey(KeyCode.S) ? -1 : 0;

        // Detectar y ejecutar animaciones de ataque con las teclas direccionales
        if (Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.DownArrow) || Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.RightArrow))
        {
            if (Time.time >= lastFireTime + fireCooldown)
            {
                HandleAttackInput();
            }
        }
        else
        {
            UpdateMovementAnimationState();
        }
    }

    void FixedUpdate()
    {
        if (isDead)
        {
            rb.velocity = Vector2.zero;
            return;
        }

        // Mover al jugador usando el Rigidbody solo con WASD
        Vector2 movement = new Vector2(moveHorizontal, moveVertical).normalized;
        rb.velocity = movement * moveSpeed;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Enemy") || collision.gameObject.CompareTag("EnemyB"))
        {
            TakeDamage(1);
        }
    }

    // M�todo original para da�o f�sico
    public void TakeDamage(int damage)
    {
        ApplyDamage(damage);
        StartCoroutine(ChangeColorTemporary(lowHealthColor));
    }

    // Sobrecarga para da�o con tipo
    public void TakeDamage(int damage, DamageType damageType)
    {
        // Detener cualquier efecto existente si el tipo de da�o es diferente
        if (damageType != DamageType.Poison && poisonCoroutine != null)
        {
            StopCoroutine(poisonCoroutine);
            poisonCoroutine = null;
        }

        if (damageType != DamageType.Fire && fireCooldownCoroutine != null)
        {
            StopCoroutine(fireCooldownCoroutine);
            fireCooldownCoroutine = null;
            fireCooldown = 0.5f; // Restaurar el valor original
        }

        if (damageType != DamageType.Ice && iceSpeedCoroutine != null)
        {
            StopCoroutine(iceSpeedCoroutine);
            iceSpeedCoroutine = null;
            moveSpeed = 5f; // Restaurar el valor original
        }

        switch (damageType)
        {
            case DamageType.Physical:
                ApplyDamage(damage);
                StartCoroutine(ChangeColorTemporary(physicalDamageColor));
                break;
            case DamageType.Magical:
                ApplyDamage(damage * 2); // Ejemplo: el da�o m�gico es doble
                StartCoroutine(ChangeColorTemporary(magicalDamageColor));
                break;
            case DamageType.Fire:
                ApplyDamage(damage);
                fireCooldownCoroutine = StartCoroutine(ApplyFireDamage(fireDamageCooldownIncrease, fireDamageDuration));
                StartCoroutine(ChangeColorTemporary(fireDamageColor));
                break;
            case DamageType.Ice:
                ApplyDamage(damage);
                iceSpeedCoroutine = StartCoroutine(ApplyIceDamage(iceDamageSpeedReduction, iceDamageDuration));
                StartCoroutine(ChangeColorTemporary(iceDamageColor));
                break;
            case DamageType.Poison:
                ApplyDamage(damage);
                poisonCoroutine = StartCoroutine(ApplyPoisonDamage(poisonDamagePerSecond, poisonDuration));
                StartCoroutine(ChangeColorTemporary(poisonDamageColor));
                break;
        }
    }

    private void ApplyDamage(int damage)
    {
        currentHealth -= damage;
        currentHealth = Mathf.Max(currentHealth, 0);

        // Usar operador ternario para cambiar el color basado en la salud
        spriteRenderer.color = currentHealth <= lowHealthThreshold ? lowHealthColor : originalColor;

        if (currentHealth <= 0)
        {
            Die();
        }
    }

    private IEnumerator ChangeColorTemporary(Color damageColor)
    {
        Color original = spriteRenderer.color;
        spriteRenderer.color = damageColor;
        yield return new WaitForSeconds(damageColorDuration);
        spriteRenderer.color = currentHealth <= lowHealthThreshold ? lowHealthColor : originalColor;
    }

    private IEnumerator ApplyPoisonDamage(int damagePerSecond, float duration)
    {
        float elapsed = 0f;
        while (elapsed < duration)
        {
            ApplyDamage(damagePerSecond);
            yield return new WaitForSeconds(1f);
            elapsed += 1f;
        }
        poisonCoroutine = null;
    }

    private IEnumerator ApplyFireDamage(float cooldownIncrease, float duration)
    {
        fireCooldown += cooldownIncrease;
        yield return new WaitForSeconds(duration);
        fireCooldown -= cooldownIncrease;
    }

    private IEnumerator ApplyIceDamage(float speedReduction, float duration)
    {
        moveSpeed -= speedReduction;
        yield return new WaitForSeconds(duration);
        moveSpeed += speedReduction;
    }

    private void Die()
    {
        isDead = true;
        animator.SetInteger("Player", 7);

        StartCoroutine(WaitAndRestartScene(deathAnimationTime));
    }

    private IEnumerator WaitAndRestartScene(float waitTime)
    {
        yield return new WaitForSeconds(waitTime);
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    private void UpdateMovementAnimationState()
    {
        // Actualizar la animaci�n de movimiento solo con WASD
        if (Input.GetKey(KeyCode.W))
            animator.SetInteger("Player", 1);
        else if (Input.GetKey(KeyCode.S))
            animator.SetInteger("Player", 2);
        else if (Input.GetKey(KeyCode.D))
        {
            transform.localScale = new Vector3(1, 1, 1);
            animator.SetInteger("Player", 3);
        }
        else if (Input.GetKey(KeyCode.A))
        {
            transform.localScale = new Vector3(-1, 1, 1);
            animator.SetInteger("Player", 3);
        }
        else
            animator.SetInteger("Player", 0);
    }

    private void HandleAttackInput()
    {
        // Detectar y ejecutar animaciones de ataque con las teclas direccionales
        if (Input.GetKey(KeyCode.UpArrow))
        {
            lastFireTime = Time.time;
            animator.SetInteger("Player", 4);
            FireBullet(Vector2.up);
        }
        else if (Input.GetKey(KeyCode.DownArrow))
        {
            lastFireTime = Time.time;
            animator.SetInteger("Player", 5);
            FireBullet(Vector2.down);
        }
        else if (Input.GetKey(KeyCode.LeftArrow))
        {
            lastFireTime = Time.time;
            transform.localScale = new Vector3(-1, 1, 1);
            animator.SetInteger("Player", 6);
            FireBullet(Vector2.left);
        }
        else if (Input.GetKey(KeyCode.RightArrow))
        {
            lastFireTime = Time.time;
            transform.localScale = new Vector3(1, 1, 1);
            animator.SetInteger("Player", 6);
            FireBullet(Vector2.right);
        }
    }

    private void FireBullet(Vector2 direction)
    {
        Vector2 spawnPosition = rb.position + direction * bulletSpawnRadius;
        GameObject bullet = Instantiate(bulletPrefab, spawnPosition, Quaternion.identity);
        bullet.GetComponent<Rigidbody2D>().velocity = direction * moveSpeed;
    }
}

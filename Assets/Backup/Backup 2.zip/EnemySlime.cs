using UnityEngine;

public class EnemySlime : Enemy
{
    [SerializeField] private Color lowHealthColor = Color.red; // Color cuando tiene baja salud
    private SpriteRenderer spriteRenderer;

    protected override void Start()
    {
        base.Start(); // Llama a la funcionalidad b�sica del enemigo
        spriteRenderer = GetComponent<SpriteRenderer>(); // Obtiene el componente SpriteRenderer
    }

    protected override void Update()
    {
        base.Update(); // Llama a la funcionalidad b�sica de movimiento
    }

    public override void TakeDamage(int damage)
    {
        base.TakeDamage(damage);

        // Si la salud est� baja, cambia el color al de baja salud
        if (health == 1)
        {
            ChangeColor(lowHealthColor);
        }
    }

    private void ChangeColor(Color newColor)
    {
        // Cambia el color del sprite
        if (spriteRenderer != null)
        {
            spriteRenderer.color = newColor;
        }
    }

    protected override void OnCollisionEnter2D(Collision2D collision)
    {
        // Verifica si el enemigo colisiona con el jugador
        if (collision.gameObject.CompareTag("Player"))
        {
            Player player = collision.gameObject.GetComponent<Player>();
            if (player != null)
            {
                player.TakeDamage(damageToPlayer, (Player.DamageType)damageType); // Asegura que se llame con el tipo de da�o correcto
                Die(); // Llama a la funci�n Die espec�fica del Slime
            }
        }
        else
        {
            // Mant�n el comportamiento general para otras colisiones
            base.OnCollisionEnter2D(collision);
        }
    }

    protected override void Die()
    {
        base.Die();
    }
}

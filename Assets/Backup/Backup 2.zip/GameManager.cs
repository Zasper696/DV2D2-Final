using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    private enum GameState { Start, WaveActive, Transition, GameOver }
    private GameState currentState;

    [SerializeField] private WaveConfigScriptableObject[] waves; // Configuraciones de oleadas

    private int currentWave = 1; // Iniciar desde la oleada 1
    private int enemiesDefeatedInWave = 0;
    private SpawnManager[] spawners;
    private float nextRoundCountdown;

    [Header("Player Health UI")]
    public Slider playerHealthBar;
    public int playerMaxHealth = 100;
    private int playerCurrentHealth;
    public Text playerHealthText;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        spawners = FindObjectsOfType<SpawnManager>();

        if (playerHealthBar == null)
        {
            Debug.LogError("Player Health Bar not assigned in the inspector.");
            return;
        }

        if (playerHealthText == null)
        {
            Debug.LogError("Player Health Text not assigned in the inspector.");
            return;
        }

        ChangeState(GameState.Start);

        playerCurrentHealth = playerMaxHealth;
        playerHealthBar.maxValue = playerMaxHealth;
        playerHealthBar.value = playerCurrentHealth;
        UpdatePlayerHealthUI();
    }

    private void Update()
    {
        switch (currentState)
        {
            case GameState.Start:
                StartNextWave();
                break;
            case GameState.WaveActive:
                // L�gica de la oleada activa
                break;
            case GameState.Transition:
                nextRoundCountdown -= Time.deltaTime;
                if (nextRoundCountdown <= 0)
                {
                    StartNextWave();
                }
                break;
            case GameState.GameOver:
                // L�gica del fin del juego
                break;
        }
    }

    private void ChangeState(GameState newState)
    {
        currentState = newState;
        switch (currentState)
        {
            case GameState.Start:
                // L�gica de inicializaci�n
                StartNextWave();
                break;
            case GameState.WaveActive:
                // Iniciar oleada
                break;
            case GameState.Transition:
                // Iniciar transici�n
                nextRoundCountdown = 5f; // Tiempo de transici�n entre oleadas
                break;
            case GameState.GameOver:
                // Fin del juego
                break;
        }
    }

    public void PlayerTakeDamage(int damage)
    {
        playerCurrentHealth -= damage;
        playerHealthBar.value = playerCurrentHealth;
        UpdatePlayerHealthUI();

        if (playerCurrentHealth <= 0)
        {
            // L�gica de perder el juego
            Debug.Log("Player has been defeated!");
        }
    }

    private void UpdatePlayerHealthUI()
    {
        playerHealthText.text = "Player Health: " + playerCurrentHealth;
    }

    public void EnemyDefeated()
    {
        enemiesDefeatedInWave++;
        Debug.Log("Enemy defeated. Total defeated in wave: " + enemiesDefeatedInWave);
        if (enemiesDefeatedInWave >= waves[currentWave - 1].numberOfEnemies)
        {
            EndCurrentWave();
        }
    }

    private void StartNextWave()
    {
        if (currentWave <= waves.Length)
        {
            Debug.Log("Starting wave " + currentWave);
            enemiesDefeatedInWave = 0;
            ChangeState(GameState.WaveActive); // Cambiar a estado WaveActive

            foreach (SpawnManager spawner in spawners)
            {
                spawner.StartWave(currentWave - 1, waves[currentWave - 1]);
            }
        }
        else
        {
            Debug.Log("All waves completed. Restarting level.");
            RestartLevel();
        }
    }

    private void EndCurrentWave()
    {
        Debug.Log("Ending wave " + currentWave);
        foreach (SpawnManager spawner in spawners)
        {
            spawner.StopSpawning();
        }

        DestroyAllEnemies();

        currentWave++;
        if (currentWave <= waves.Length)
        {
            ChangeState(GameState.Transition); // Cambiar a estado Transition
            Debug.Log("Next round starts in " + nextRoundCountdown + " seconds.");
        }
        else
        {
            Debug.Log("All waves completed. Restarting level.");
            ChangeState(GameState.GameOver); // Cambiar a estado GameOver
        }
    }

    private void DestroyAllEnemies()
    {
        foreach (GameObject enemy in GameObject.FindGameObjectsWithTag("Enemy"))
        {
            Destroy(enemy);
        }
    }

    private void RestartLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    // M�todos para obtener la informaci�n requerida por los scripts
    public int GetCurrentWave()
    {
        return currentWave;
    }

    public int GetRemainingEnemies()
    {
        return waves[currentWave - 1].numberOfEnemies - enemiesDefeatedInWave;
    }

    public float GetNextRoundCountdown()
    {
        return nextRoundCountdown;
    }
}

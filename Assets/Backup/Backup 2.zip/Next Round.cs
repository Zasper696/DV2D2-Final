using UnityEngine;
using UnityEngine.UI;

public class NextRound : MonoBehaviour
{
    public Text timerText; // Referencia al componente Text
    private GameManager gameManager;

    void Start()
    {
        gameManager = GameManager.Instance;
    }

    void Update()
    {
        if (gameManager != null)
        {
            float countdown = gameManager.GetNextRoundCountdown();
            timerText.text = "Next Round: " + Mathf.Max(0, Mathf.CeilToInt(countdown)).ToString();
        }
    }
}

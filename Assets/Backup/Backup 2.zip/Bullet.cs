using UnityEngine;

public class Bullet : MonoBehaviour
{
    // Puedes definir algunas propiedades generales aqu�, como el da�o que pueda infligir
    // en caso de que se desee que todos los tipos de proyectiles compartan esas caracter�sticas.
    // Por ejemplo:
    [SerializeField] protected int damage = 1;

    // M�todo para obtener el da�o del proyectil
    public int GetDamage()
    {
        return damage;
    }

    // Este m�todo podr�a ser sobreescrito en las clases derivadas si es necesario
    public virtual void OnTriggerEnter2D(Collider2D other)
    {
        // Puedes a�adir l�gica para la colisi�n que sea aplicable a todos los tipos de proyectiles
    }
}

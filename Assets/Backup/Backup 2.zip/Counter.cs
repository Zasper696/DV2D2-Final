using UnityEngine;
using UnityEngine.UI;

public class Counter : MonoBehaviour
{
    public Text enemyCounterText; // Referencia al componente Text
    private GameManager gameManager;

    void Start()
    {
        gameManager = GameManager.Instance;
    }

    void Update()
    {
        if (gameManager != null)
        {
            int remainingEnemies = gameManager.GetRemainingEnemies();
            enemyCounterText.text = "Enemies Left: " + remainingEnemies.ToString();
        }
    }
}

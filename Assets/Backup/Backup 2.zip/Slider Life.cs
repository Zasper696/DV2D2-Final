using UnityEngine;
using UnityEngine.UI;

public class SliderLife : MonoBehaviour
{
    public Slider playerHealthSlider;
    public Player player;

    void Start()
    {
        if (player != null && playerHealthSlider != null)
        {
            playerHealthSlider.maxValue = player.maxHealth;
            playerHealthSlider.value = player.currentHealth;
        }
    }

    void Update()
    {
        if (player != null && playerHealthSlider != null)
        {
            playerHealthSlider.value = player.currentHealth;
        }
    }
}

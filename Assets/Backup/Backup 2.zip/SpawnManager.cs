using UnityEngine;

public class SpawnManager : MonoBehaviour
{
    private WaveConfigScriptableObject currentWaveConfig; // Configuraci�n de la oleada actual
    private bool isSpawning = false; // Indicador de si el spawn est� activo
    private int currentWaveIndex = 0; // �ndice de la oleada actual

    public int GetCurrentWaveIndex()
    {
        return currentWaveIndex;
    }

    public void StartWave(int waveIndex, WaveConfigScriptableObject waveConfig)
    {
        // Establece el �ndice y la configuraci�n de la oleada actual
        currentWaveIndex = waveIndex;
        currentWaveConfig = waveConfig;

        // Decide si activar el spawning o no
        isSpawning = !currentWaveConfig.disableDuringWave;

        // Si est� activado el spawning, comienza a invocar a los enemigos a intervalos definidos
        if (isSpawning)
        {
            InvokeRepeating(nameof(SpawnEnemy), 0f, currentWaveConfig.spawnInterval);
        }
        else
        {
            CancelInvoke(nameof(SpawnEnemy));
        }
    }

    public void StopSpawning()
    {
        // Cancela cualquier invocaci�n activa para detener el spawn
        CancelInvoke(nameof(SpawnEnemy));
        isSpawning = false;
    }

    private void SpawnEnemy()
    {
        // Verifica si el spawning est� activo
        if (!isSpawning) return;

        // Calcula la suma total de las probabilidades de todos los enemigos
        float totalProbability = 0f;
        foreach (var enemy in currentWaveConfig.enemies)
        {
            totalProbability += enemy.spawnProbability;
        }

        // Genera un valor aleatorio para elegir un enemigo
        float randomValue = Random.Range(0f, totalProbability);
        float accumulatedProbability = 0f;

        // Selecciona un enemigo basado en la probabilidad acumulada
        foreach (var enemy in currentWaveConfig.enemies)
        {
            accumulatedProbability += enemy.spawnProbability;
            if (randomValue <= accumulatedProbability)
            {
                Instantiate(enemy.enemyPrefab, transform.position, Quaternion.identity);
                break;
            }
        }
    }

    public float GetIntervalBetweenWaves()
    {
        return currentWaveConfig.intervalBetweenWaves;
    }
}

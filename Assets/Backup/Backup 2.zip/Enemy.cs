using UnityEngine;

public class Enemy : MonoBehaviour
{
    public enum EnemyType
    {
        Slime,
        FlyingEye,
        Goblin,
        Mushroom,
        Skeleton
    }

    public enum DamageType
    {
        Physical,
        Magical,
        Fire,
        Ice,
        Poison
    }

    [SerializeField] private EnemyType enemyType; // Tipo de enemigo
    [SerializeField] protected int health; // Salud del enemigo
    [SerializeField] protected float speed; // Velocidad del enemigo
    [SerializeField] protected int damageToPlayer; // Da�o al jugador
    [SerializeField] protected DamageType damageType; // Tipo de da�o
    [SerializeField] protected float detectionRadius; // Radio de detecci�n del enemigo
    [SerializeField] protected float stuckTimeThreshold = 3f;
    [SerializeField] protected float minimumMovementThreshold = 0.1f;

    protected Vector2 movementDirection;
    protected Transform player;
    private Vector2 lastPosition;
    private float timeStuck = 0;

    private void Awake()
    {
        // Asignar valores por defecto basados en el tipo de enemigo
        SetDefaultValues();
    }

    protected virtual void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
        ChooseNewDirection();
    }

    protected virtual void Update()
    {
        Move();
        CheckIfStuck();
        FollowPlayer();
    }

    private void Move()
    {
        transform.Translate(movementDirection * speed * Time.deltaTime);
    }

    private void FollowPlayer()
    {
        if (player && Vector2.Distance(transform.position, player.position) <= detectionRadius)
        {
            movementDirection = (player.position - transform.position).normalized;
        }
    }

    private void CheckIfStuck()
    {
        if (Vector2.Distance(transform.position, lastPosition) < minimumMovementThreshold)
        {
            timeStuck += Time.deltaTime;
            if (timeStuck >= stuckTimeThreshold)
            {
                ChooseNewDirection();
                timeStuck = 0;
            }
        }
        else
        {
            timeStuck = 0;
        }
        lastPosition = transform.position;
    }

    protected void ChooseNewDirection()
    {
        float angle = Random.Range(0f, 360f);
        movementDirection = new Vector2(Mathf.Cos(angle * Mathf.Deg2Rad), Mathf.Sin(angle * Mathf.Deg2Rad));
    }

    protected virtual void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Wall"))
        {
            ChooseNewDirection();
        }

        if (collision.gameObject.CompareTag("Player"))
        {
            Player player = collision.gameObject.GetComponent<Player>();
            if (player != null)
            {
                player.TakeDamage(damageToPlayer, (Player.DamageType)damageType);
                Die();
            }
        }
    }

    public virtual void TakeDamage(int damage)
    {
        health -= damage;
        if (health <= 0)
        {
            Die();
        }
    }

    protected virtual void Die()
    {
        Debug.Log("Enemy died.");
        GameManager.Instance.EnemyDefeated();
        Destroy(gameObject);
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, detectionRadius);
    }

    private void SetDefaultValues()
    {
        switch (enemyType)
        {
            case EnemyType.Slime:
                health = 3;
                speed = 2f;
                damageToPlayer = 1;
                damageType = DamageType.Physical;
                detectionRadius = 5f;
                break;
            case EnemyType.FlyingEye:
                health = 2;
                speed = 4f;
                damageToPlayer = 1;
                damageType = DamageType.Magical;
                detectionRadius = 7f;
                break;
            case EnemyType.Goblin:
                health = 5;
                speed = 3f;
                damageToPlayer = 2;
                damageType = DamageType.Physical;
                detectionRadius = 6f;
                break;
            case EnemyType.Mushroom:
                health = 4;
                speed = 1.5f;
                damageToPlayer = 1;
                damageType = DamageType.Poison;
                detectionRadius = 4f;
                break;
            case EnemyType.Skeleton:
                health = 6;
                speed = 2.5f;
                damageToPlayer = 2;
                damageType = DamageType.Physical;
                detectionRadius = 5f;
                break;
        }
    }
}

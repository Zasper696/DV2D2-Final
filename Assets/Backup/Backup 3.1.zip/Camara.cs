using UnityEngine;

public class Camara : MonoBehaviour
{
    [SerializeField] public Transform objetivo;
    [SerializeField] public float smoothSpeed = 0.125f;
    [SerializeField] private Vector3 velocity = Vector3.zero;

    private float limiteXMinimo;
    private float limiteXMaximo;
    private float limiteYMinimo;
    private float limiteYMaximo;

    void Start()
    {
        objetivo = GameObject.FindGameObjectWithTag("Player").transform;
        InitializeCameraLimits();
    }

    void FixedUpdate()
    {
        if (objetivo != null)
        {
            Vector3 posicionObjetivo = objetivo.position;
            posicionObjetivo.x = Mathf.Clamp(posicionObjetivo.x, limiteXMinimo, limiteXMaximo);
            posicionObjetivo.y = Mathf.Clamp(posicionObjetivo.y, limiteYMinimo, limiteYMaximo);
            posicionObjetivo.z = transform.position.z;
            transform.position = Vector3.SmoothDamp(transform.position, posicionObjetivo, ref velocity, smoothSpeed);
        }
    }

    private void InitializeCameraLimits()
    {
        CamaraConfig config = CamaraManager.Instance.GetConfigForCurrentScene();
        if (config != null)
        {
            limiteXMinimo = config.limiteXMinimo;
            limiteXMaximo = config.limiteXMaximo;
            limiteYMinimo = config.limiteYMinimo;
            limiteYMaximo = config.limiteYMaximo;
        }
        else
        {
            Debug.LogWarning("Camera limits not set for the current scene.");
        }
    }
}

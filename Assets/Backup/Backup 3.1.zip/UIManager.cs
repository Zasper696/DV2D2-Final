using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    public static UIManager Instance { get; private set; }

    [Header("Player Health UI")]
    public Slider playerHealthSlider;
    public Text playerHealthText;

    [Header("Enemy Counter UI")]
    public Text enemyCounterText;

    [Header("Wave Counter UI")]
    public Text waveText;

    [Header("Next Round Countdown UI")]
    public Text nextRoundText;

    [Header("UI Prefab")]
    public GameObject uiPrefab;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
            InstantiateUIPrefab();
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        InitializeUI();
    }

    private void InstantiateUIPrefab()
    {
        if (uiPrefab != null)
        {
            GameObject uiInstance = Instantiate(uiPrefab);
            DontDestroyOnLoad(uiInstance);
            AssignUIElements();
        }
        else
        {
            Debug.LogError("UI Prefab is not assigned.");
        }
    }

    private void AssignUIElements()
    {
        playerHealthSlider = GameObject.FindWithTag("UI 5")?.GetComponent<Slider>();
        playerHealthText = GameObject.FindWithTag("UI 4")?.GetComponent<Text>();
        enemyCounterText = GameObject.FindWithTag("UI 1")?.GetComponent<Text>();
        waveText = GameObject.FindWithTag("UI 2")?.GetComponent<Text>();
        nextRoundText = GameObject.FindWithTag("UI 3")?.GetComponent<Text>();

        if (playerHealthSlider == null) Debug.LogError("Player Health Slider not found!");
        if (playerHealthText == null) Debug.LogError("Player Health Text not found!");
        if (enemyCounterText == null) Debug.LogError("Enemy Counter Text not found!");
        if (waveText == null) Debug.LogError("Wave Text not found!");
        if (nextRoundText == null) Debug.LogError("Next Round Text not found!");
    }

    private void InitializeUI()
    {
        if (playerHealthSlider == null || playerHealthText == null ||
            enemyCounterText == null || waveText == null || nextRoundText == null)
        {
            Debug.LogError("UI elements not assigned in the inspector.");
            return;
        }

        UpdatePlayerHealthUI(PlayerData.Instance.health);
        // Aqu�, aseg�rate de que las otras partes del HUD tambi�n se actualicen correctamente
    }

    public void UpdatePlayerHealthUI(int currentHealth)
    {
        if (playerHealthSlider != null && playerHealthText != null)
        {
            playerHealthSlider.value = currentHealth;
            playerHealthText.text = "Player: " + currentHealth;
        }
    }

    public void UpdateEnemyCounterUI(int remainingEnemies)
    {
        if (enemyCounterText != null)
        {
            enemyCounterText.text = "Enemies Left: " + remainingEnemies;
        }
    }

    public void UpdateWaveText(int currentWave)
    {
        if (waveText != null)
        {
            waveText.text = "Actual Wave: " + currentWave;
        }
    }

    public void UpdateNextRoundCountdownUI(float countdown)
    {
        if (nextRoundText != null)
        {
            nextRoundText.text = "Next Round In: " + countdown.ToString("F1") + "s";
        }
    }

    public void ResetUIReferences()
    {
        AssignUIElements();
        InitializeUI();
    }
}
